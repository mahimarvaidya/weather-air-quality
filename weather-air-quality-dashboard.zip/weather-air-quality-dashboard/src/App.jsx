import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Search,
  CloudRain,
  Sun,
  Cloud,
  CloudLightning,
  CloudSnow,
  Wind,
  Droplets,
  Thermometer,
  Compass,
  AlertCircle,
  RefreshCw,
  Clock,
  Eye,
  Gauge,
  Sunrise,
  Sunset,
  ChevronRight
} from 'lucide-react';

const PRESETS = [
  { name: 'Bengaluru', lat: 12.9716, lon: 77.5946, country: 'India' },
  { name: 'Tokyo', lat: 35.6762, lon: 139.6503, country: 'Japan' },
  { name: 'London', lat: 51.5074, lon: -0.1278, country: 'United Kingdom' },
  { name: 'New York', lat: 40.7128, lon: -74.006, country: 'United States' },
  { name: 'Paris', lat: 48.8566, lon: 2.3522, country: 'France' },
  { name: 'Sydney', lat: -33.8688, lon: 151.2093, country: 'Australia' }
];

const getWeatherCondition = (code) => {
  if (code === 0) return { label: 'Clear Sky', icon: Sun, color: 'text-amber-400' };
  if (code >= 1 && code <= 3) return { label: 'Partly Cloudy', icon: Cloud, color: 'text-slate-300' };
  if (code >= 45 && code <= 48) return { label: 'Foggy', icon: Cloud, color: 'text-slate-400' };
  if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return { label: 'Rain', icon: CloudRain, color: 'text-blue-400' };
  if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) return { label: 'Snowfall', icon: CloudSnow, color: 'text-sky-200' };
  if (code >= 95) return { label: 'Thunderstorm', icon: CloudLightning, color: 'text-purple-400' };
  return { label: 'Overcast', icon: Cloud, color: 'text-slate-400' };
};

const getAqiCategory = (aqi) => {
  if (aqi == null) return { label: 'N/A', color: 'text-slate-400', bg: 'bg-slate-800', bar: 'bg-slate-500' };
  if (aqi <= 50) return { label: 'Good', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/30', bar: 'bg-emerald-400' };
  if (aqi <= 100) return { label: 'Moderate', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/30', bar: 'bg-amber-400' };
  if (aqi <= 150) return { label: 'Sensitive Unhealthy', color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/30', bar: 'bg-orange-400' };
  if (aqi <= 200) return { label: 'Unhealthy', color: 'text-rose-400', bg: 'bg-rose-500/10 border-rose-500/30', bar: 'bg-rose-500' };
  if (aqi <= 300) return { label: 'Very Unhealthy', color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/30', bar: 'bg-purple-500' };
  return { label: 'Hazardous', color: 'text-red-500', bg: 'bg-red-500/20 border-red-500/40', bar: 'bg-red-600' };
};

export default function App() {
  const [selectedCity, setSelectedCity] = useState(PRESETS[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [weatherData, setWeatherData] = useState(null);
  const [aqiData, setAqiData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [unit, setUnit] = useState('metric'); // 'metric' (°C, km/h) | 'imperial' (°F, mph)

  const searchDebounceRef = useRef(null);

  // Fetch Weather & Air Quality in parallel
  const fetchDashboardData = async (lat, lon) => {
    setLoading(true);
    setError(null);
    try {
      const weatherPromise = fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,surface_pressure,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,weather_code,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max&timezone=auto`
      ).then(res => {
        if (!res.ok) throw new Error('Weather API error');
        return res.json();
      });

      const aqiPromise = fetch(
        `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=us_aqi,pm10,pm2_5,nitrogen_dioxide,ozone,sulphur_dioxide&timezone=auto`
      ).then(res => {
        if (!res.ok) throw new Error('AQI API error');
        return res.json();
      });

      const [weather, aqi] = await Promise.all([weatherPromise, aqiPromise]);
      setWeatherData(weather);
      setAqiData(aqi);
    } catch (err) {
      setError(err.message || 'Unable to connect to meteorological servers.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData(selectedCity.lat, selectedCity.lon);
  }, [selectedCity]);

  // Geocoding live search autocomplete
  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);

    if (!val.trim()) {
      setSearchResults([]);
      return;
    }

    searchDebounceRef.current = setTimeout(async () => {
      setIsSearching(true);
      try {
        const res = await fetch(
          `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(val)}&count=5&language=en&format=json`
        );
        const data = await res.json();
        setSearchResults(data.results || []);
      } catch {
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 350);
  };

  const handleSelectSearchResult = (result) => {
    setSelectedCity({
      name: result.name,
      country: result.country || '',
      lat: result.latitude,
      lon: result.longitude
    });
    setSearchQuery('');
    setSearchResults([]);
  };

  // Temperature and speed converters
  const formatTemp = (celsius) => {
    if (celsius == null) return '--';
    if (unit === 'imperial') {
      return `${Math.round((celsius * 9) / 5 + 32)}°F`;
    }
    return `${Math.round(celsius)}°C`;
  };

  const formatSpeed = (kmh) => {
    if (kmh == null) return '--';
    if (unit === 'imperial') {
      return `${Math.round(kmh * 0.621371)} mph`;
    }
    return `${Math.round(kmh)} km/h`;
  };

  const currentCondition = useMemo(() => {
    if (!weatherData?.current) return { label: '...', icon: Sun, color: 'text-amber-400' };
    return getWeatherCondition(weatherData.current.weather_code);
  }, [weatherData]);

  const currentAqi = aqiData?.current?.us_aqi;
  const aqiInfo = useMemo(() => getAqiCategory(currentAqi), [currentAqi]);

  const CurrentIcon = currentCondition.icon;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8 flex justify-center items-center">
      <div className="w-full max-w-5xl bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl backdrop-blur-md">
        
        {/* Top Navbar */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-2xl font-black tracking-tight text-white">Atmosphere</h1>
              <span className="text-[11px] font-semibold tracking-wide uppercase px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                Live Open-Meteo REST API
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">Real-time planetary meteorology & air quality</p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto relative">
            {/* Search Input */}
            <div className="relative flex-1 md:w-72">
              <input
                type="text"
                placeholder="Search worldwide city..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full bg-slate-800/90 border border-slate-700/80 rounded-xl px-3.5 py-2 pl-9 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              {isSearching && (
                <RefreshCw className="w-3.5 h-3.5 text-indigo-400 animate-spin absolute right-3 top-3" />
              )}

              {/* Autocomplete Dropdown */}
              {searchResults.length > 0 && (
                <div className="absolute z-50 left-0 right-0 mt-2 bg-slate-800 border border-slate-700 rounded-xl shadow-xl overflow-hidden">
                  {searchResults.map((item) => (
                    <button
                      key={`${item.id || item.latitude}-${item.longitude}`}
                      onClick={() => handleSelectSearchResult(item)}
                      className="w-full px-4 py-2.5 text-left text-xs text-slate-200 hover:bg-indigo-600 hover:text-white transition flex items-center justify-between"
                    >
                      <span>
                        <strong className="font-semibold">{item.name}</strong>
                        {item.admin1 ? `, ${item.admin1}` : ''} ({item.country})
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 opacity-60" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Units Toggle */}
            <button
              onClick={() => setUnit(unit === 'metric' ? 'imperial' : 'metric')}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-semibold text-slate-200 transition"
            >
              {unit === 'metric' ? '°C, km/h' : '°F, mph'}
            </button>
          </div>
        </header>

        {/* Quick Presets */}
        <div className="flex gap-2 overflow-x-auto pb-3 mb-6 scrollbar-none text-xs">
          {PRESETS.map((city) => (
            <button
              key={city.name}
              onClick={() => setSelectedCity(city)}
              className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition font-medium ${
                selectedCity.name === city.name
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-slate-800/80 text-slate-400 hover:text-slate-100 hover:bg-slate-700'
              }`}
            >
              {city.name}
            </button>
          ))}
        </div>

        {/* Error Notification */}
        {error && (
          <div className="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-center justify-between text-rose-300 text-sm">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
            <button
              onClick={() => fetchDashboardData(selectedCity.lat, selectedCity.lon)}
              className="px-3 py-1 bg-rose-500/20 hover:bg-rose-500/30 rounded-lg text-xs font-semibold transition"
            >
              Retry
            </button>
          </div>
        )}

        {/* Loading Spinner */}
        {loading ? (
          <div className="py-24 flex flex-col items-center justify-center gap-3 text-slate-400">
            <RefreshCw className="w-7 h-7 animate-spin text-indigo-400" />
            <p className="text-sm">Connecting to meteorology & air stations...</p>
          </div>
        ) : weatherData ? (
          <div className="space-y-6">
            
            {/* Top Grid: Hero Weather + Air Quality Panel */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Primary Weather Card */}
              <div className="md:col-span-2 bg-gradient-to-br from-indigo-950/40 via-slate-800/40 to-slate-800/20 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between relative overflow-hidden">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs uppercase tracking-wider text-slate-400 font-semibold">
                      {selectedCity.country || 'Global Station'}
                    </span>
                    <h2 className="text-3xl md:text-4xl font-extrabold text-white mt-1">
                      {selectedCity.name}
                    </h2>
                    <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-2">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      <span>{weatherData.current?.time?.replace('T', ' ')}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <CurrentIcon className={`w-16 h-16 ${currentCondition.color} inline-block`} />
                    <div className="text-sm font-semibold text-slate-300 mt-1">{currentCondition.label}</div>
                  </div>
                </div>

                <div className="mt-8 flex items-baseline gap-4">
                  <span className="text-6xl font-black text-white tracking-tight">
                    {formatTemp(weatherData.current?.temperature_2m)}
                  </span>
                  <span className="text-slate-400 text-sm">
                    Feels like <strong className="text-slate-200">{formatTemp(weatherData.current?.apparent_temperature)}</strong>
                  </span>
                </div>
              </div>

              {/* Air Quality Index Card */}
              <div className={`border rounded-2xl p-6 flex flex-col justify-between ${aqiInfo.bg}`}>
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold tracking-wider text-slate-400 uppercase">
                      Air Quality Index
                    </span>
                    <Gauge className={`w-4 h-4 ${aqiInfo.color}`} />
                  </div>

                  <div className="mt-4 flex items-baseline gap-2">
                    <span className="text-5xl font-black text-white">{currentAqi ?? '--'}</span>
                    <span className="text-xs text-slate-400">US AQI</span>
                  </div>

                  <div className={`mt-1 text-sm font-bold ${aqiInfo.color}`}>
                    {aqiInfo.label}
                  </div>

                  {/* AQI Progress Meter */}
                  <div className="w-full bg-slate-800 rounded-full h-2 mt-4 overflow-hidden border border-slate-700/50">
                    <div
                      className={`h-full ${aqiInfo.bar}`}
                      style={{ width: `${Math.min(100, (currentAqi / 300) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Pollutant Micro-matrix */}
                <div className="grid grid-cols-2 gap-2 mt-6 pt-4 border-t border-slate-800/80 text-[11px]">
                  <div>
                    <span className="text-slate-400">PM2.5: </span>
                    <span className="font-semibold text-slate-200">{aqiData?.current?.pm2_5 ?? '--'} µg/m³</span>
                  </div>
                  <div>
                    <span className="text-slate-400">PM10: </span>
                    <span className="font-semibold text-slate-200">{aqiData?.current?.pm10 ?? '--'} µg/m³</span>
                  </div>
                  <div>
                    <span className="text-slate-400">NO₂: </span>
                    <span className="font-semibold text-slate-200">{aqiData?.current?.nitrogen_dioxide ?? '--'} µg/m³</span>
                  </div>
                  <div>
                    <span className="text-slate-400">O₃: </span>
                    <span className="font-semibold text-slate-200">{aqiData?.current?.ozone ?? '--'} µg/m³</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Meteorological Matrix */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                  <Droplets className="w-3.5 h-3.5 text-sky-400" />
                  <span>Humidity</span>
                </div>
                <div className="text-lg font-bold text-slate-100">{weatherData.current?.relative_humidity_2m}%</div>
              </div>

              <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                  <Wind className="w-3.5 h-3.5 text-teal-400" />
                  <span>Wind</span>
                </div>
                <div className="text-lg font-bold text-slate-100">{formatSpeed(weatherData.current?.wind_speed_10m)}</div>
              </div>

              <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                  <Compass className="w-3.5 h-3.5 text-purple-400" />
                  <span>Bearing</span>
                </div>
                <div className="text-lg font-bold text-slate-100">{weatherData.current?.wind_direction_10m}°</div>
              </div>

              <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                  <span>Max UV</span>
                </div>
                <div className="text-lg font-bold text-slate-100">{weatherData.daily?.uv_index_max?.[0] ?? '--'}</div>
              </div>

              <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                  <Sunrise className="w-3.5 h-3.5 text-yellow-400" />
                  <span>Sunrise</span>
                </div>
                <div className="text-xs font-semibold text-slate-200 mt-1.5">
                  {weatherData.daily?.sunrise?.[0]?.split('T')[1] ?? '--'}
                </div>
              </div>

              <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1">
                  <Sunset className="w-3.5 h-3.5 text-orange-400" />
                  <span>Sunset</span>
                </div>
                <div className="text-xs font-semibold text-slate-200 mt-1.5">
                  {weatherData.daily?.sunset?.[0]?.split('T')[1] ?? '--'}
                </div>
              </div>
            </div>

            {/* 24-Hour Forecast Ribbon */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-2xl p-5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">24-Hour Horizon</h3>
              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
                {weatherData.hourly?.time?.slice(0, 24).map((timeStr, idx) => {
                  const hour = timeStr.split('T')[1];
                  const code = weatherData.hourly?.weather_code?.[idx];
                  const temp = weatherData.hourly?.temperature_2m?.[idx];
                  const rainChance = weatherData.hourly?.precipitation_probability?.[idx];
                  const HourIcon = getWeatherCondition(code).icon;

                  return (
                    <div
                      key={timeStr}
                      className="flex-shrink-0 flex flex-col items-center justify-between bg-slate-800/60 border border-slate-700/40 rounded-xl p-3 min-w-[70px] text-center"
                    >
                      <span className="text-[11px] text-slate-400">{hour}</span>
                      <HourIcon className="w-6 h-6 my-2 text-indigo-400" />
                      <span className="text-xs font-bold text-slate-200">{formatTemp(temp)}</span>
                      {rainChance > 0 ? (
                        <span className="text-[10px] text-sky-400 font-semibold mt-1">{rainChance}%</span>
                      ) : (
                        <span className="text-[10px] text-transparent mt-1">0%</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 7-Day Forecast */}
            <div className="bg-slate-800/30 border border-slate-800 rounded-2xl p-5">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">7-Day Extended Forecast</h3>
              <div className="divide-y divide-slate-800/80">
                {weatherData.daily?.time?.map((dateStr, idx) => {
                  const code = weatherData.daily.weather_code[idx];
                  const DayIcon = getWeatherCondition(code).icon;
                  const date = new Date(dateStr);
                  const dayName = idx === 0 ? 'Today' : date.toLocaleDateString('en-US', { weekday: 'short' });

                  return (
                    <div key={dateStr} className="py-3 flex items-center justify-between text-xs">
                      <span className="w-20 font-semibold text-slate-300">{dayName}</span>
                      <div className="flex items-center gap-2 w-32">
                        <DayIcon className="w-4 h-4 text-slate-400" />
                        <span className="text-slate-400">{getWeatherCondition(code).label}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-slate-400">{formatTemp(weatherData.daily.temperature_2m_min[idx])}</span>
                        <div className="w-24 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-indigo-500 h-full rounded-full w-3/4 mx-auto" />
                        </div>
                        <span className="font-bold text-slate-100">{formatTemp(weatherData.daily.temperature_2m_max[idx])}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        ) : null}

      </div>
    </div>
  );
}
