# Atmosphere - Live Weather & Air Quality Dashboard

A React application integrated with Open-Meteo REST APIs (Forecast, Geocoding, and Air Quality) styled with Tailwind CSS and Lucide React.

## 🚀 Getting Started in VS Code

1. **Extract the ZIP file** into your preferred directory.
2. Open the project folder in **VS Code**:
   ```bash
   code weather-air-quality-dashboard
   ```
3. Open the integrated terminal in VS Code (`Ctrl + \`` or `Cmd + \``) and install dependencies:
   ```bash
   npm install
   ```
4. Start the local development server:
   ```bash
   npm run dev
   ```
5. Open the local URL displayed in the terminal (usually `http://localhost:5173/`).

## 🧰 Tech Stack
- **Framework**: React 18 + Vite
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **APIs Used** (No API Key Required):
  - [Open-Meteo Weather Forecast API](https://open-meteo.com/en/docs)
  - [Open-Meteo Air Quality API](https://open-meteo.com/en/docs/air-quality-api)
  - [Open-Meteo Geocoding Search API](https://open-meteo.com/en/docs/geocoding-api)
